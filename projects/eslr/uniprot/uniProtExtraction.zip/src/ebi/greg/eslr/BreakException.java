package ebi.greg.eslr;

public class BreakException extends Exception
{

	public BreakException(String string)
	{
		super(string);
	}

}
