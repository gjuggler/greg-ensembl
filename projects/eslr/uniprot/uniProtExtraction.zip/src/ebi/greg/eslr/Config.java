package ebi.greg.eslr;

public class Config
{
	public static String comparaUrl;
//	public static String comparaConfig = "mysql-compara2.cnf";
//	public static String anonConfig = "mysql-ensembl.cnf";
	
	public static String inputDb;
//	public static String outputDb;
//	public static String inputTable;
//	public static String alignmentTable;
//	public static String outputTable;
	
	
}
